
function SoundManager(){
  this.play= function(type){
    console.log('play [%s] sound', type);
  };
  this.sideMusic= function(type){
    console.log('play [%s] side Music', type);
  };

}
